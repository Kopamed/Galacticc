package me.Client.example;

import me.Client.modules.Module;
import me.Client.modules.ModuleManager;
import me.Client.settings.SettingsManager;

/**  	   \/  \/  \/  \/  \/  \/  \/  \/  \/  \/ 
 *  ---->   This is just what your client main class  <-----
 *  ---->   should have		    					  <-----
 *  	   /\  /\  /\  /\  /\  /\  /\  /\  /\  /\   
 *  
 *  @author HeroCode & xTrM_
 */
public class ClientMain {
	
	public static SettingsManager setmgr;
	public static ModuleManager modulemgr;
	
	public static void setupClient(){

		setmgr = new SettingsManager(); // SettingsManager BEFORE ModuleManager loaded modules

		modulemgr = new ModuleManager();
		modulemgr.addModule(new GuiModule());
	}
}
